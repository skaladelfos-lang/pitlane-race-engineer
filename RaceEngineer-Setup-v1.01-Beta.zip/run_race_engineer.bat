@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"
title Race Engineer

set "PYEXE=python"

where python >nul 2>nul
if %errorlevel% neq 0 goto :install_python

python --version 2>&1 | findstr /C:"was not found" >nul
if %errorlevel% equ 0 goto :install_python

goto :python_ready

:install_python
echo Python was not found on this PC - installing it automatically.
echo This only happens once and may take a minute or two.
echo.

where winget >nul 2>nul
if %errorlevel% equ 0 (
    echo Installing Python via winget...
    winget install --id Python.Python.3.12 -e --source winget --accept-package-agreements --accept-source-agreements --silent >nul 2>nul
) else (
    echo Downloading the Python installer...
    powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.12.7/python-3.12.7-amd64.exe' -OutFile '%TEMP%\python-installer.exe' -UseBasicParsing"
    echo Installing Python ^(silent, no windows will pop up^)...
    "%TEMP%\python-installer.exe" /quiet InstallAllUsers=0 PrependPath=1 Include_test=0
    del "%TEMP%\python-installer.exe" >nul 2>nul
)

echo Locating the newly installed Python...

REM Try to find the real python.exe directly, so we can keep going right
REM now instead of asking for a manual restart - this sidesteps the
REM Windows Store alias issue entirely, since we call the full path
REM directly instead of relying on PATH lookup.
set "PYEXE="
for %%D in (
    "%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
    "%ProgramFiles%\Python312\python.exe"
    "%ProgramFiles%\Python313\python.exe"
    "%ProgramFiles%\Python311\python.exe"
) do (
    if exist %%D if not defined PYEXE set "PYEXE=%%~D"
)

if not defined PYEXE (
    echo.
    echo Python was installed, but this script couldn't automatically find it.
    echo Please close this window and click the Race Engineer shortcut again -
    echo a fresh window should pick it up.
    echo.
    pause
    exit /b 0
)

echo Found Python - continuing automatically.
echo.

:python_ready

if not exist ".setup_done" (
    echo Installing required packages - this only happens once...
    "%PYEXE%" -m pip install -r requirements.txt

    if !errorlevel! neq 0 (
        echo [ERROR] Failed to install dependencies. Check your internet connection.
        pause
        exit /b 1
    )

    if not exist "pyLMUSharedMemory\lmu_mmap.py" (
        echo Fetching pyLMUSharedMemory ^(tyre temps + damage library^)...
        powershell -NoProfile -Command "try { Invoke-WebRequest -Uri 'https://github.com/TinyPedal/pyLMUSharedMemory/archive/refs/heads/master.zip' -OutFile 'pyLMUSharedMemory.zip' -UseBasicParsing; Expand-Archive -Path 'pyLMUSharedMemory.zip' -DestinationPath 'pyLMUSharedMemory_extract' -Force; $inner = Get-ChildItem 'pyLMUSharedMemory_extract' -Directory | Select-Object -First 1; Move-Item $inner.FullName 'pyLMUSharedMemory'; Remove-Item 'pyLMUSharedMemory.zip' -Force; Remove-Item 'pyLMUSharedMemory_extract' -Recurse -Force; Write-Host 'pyLMUSharedMemory installed.' } catch { Write-Host 'Could not auto-download pyLMUSharedMemory - tyre temps/damage will be unavailable.' }"
    )

    echo done > ".setup_done"
    echo.
)

echo Make sure Le Mans Ultimate is running with:
echo   Settings -^> Gameplay -^> Enable Plugins = ON
echo.
echo (Keep this window open while you race - closing it disconnects you)
echo.

"%PYEXE%" agent.py

pause
