"""
Reads tyre temperature and damage data directly from LMU's built-in
shared memory interface. This data isn't available through LMU's REST
API (confirmed by testing) - it only exists in the shared memory buffer
that LMU itself writes to while running.

This relies on the pyLMUSharedMemory library (MIT licensed), maintained
by the TinyPedal project, which maps LMU's official SharedMemoryInterface
struct layout. See pyLMUSharedMemory/License.txt (fetched alongside this
file by the setup scripts) for the full license text and credits.

We don't reimplement LMU's memory layout ourselves - getting a byte
offset wrong in a hand-rolled version would silently produce garbage
data, so we depend on the maintained library instead and just extract
the handful of fields RE actually needs.
"""

import os
import sys

# When bundled into a standalone .exe, make sure the bundled copy of
# pyLMUSharedMemory (added via --add-data in build_exe.bat) is on the
# import path. When running as a plain script, it's just picked up
# from the current directory as normal.
_bundle_dir = getattr(sys, "_MEIPASS", None)
if _bundle_dir and _bundle_dir not in sys.path:
    sys.path.insert(0, _bundle_dir)

try:
    from pyLMUSharedMemory import lmu_mmap, lmu_data
    SHARED_MEMORY_AVAILABLE = True
except ImportError:
    SHARED_MEMORY_AVAILABLE = False

WHEEL_CORNERS = ["FL", "FR", "RL", "RR"]  # matches LMU's mWheels order


class SharedMemoryReader:
    """Exposes just the fields RE needs: tyre temps, tyre wear, and damage."""

    def __init__(self):
        self._info = None
        self._ready = False

    def connect(self) -> bool:
        """
        Attempts to attach to LMU's shared memory. Returns False if the
        library isn't installed or LMU isn't running yet - safe to call
        again later to retry.
        """
        if not SHARED_MEMORY_AVAILABLE:
            return False
        try:
            self._info = lmu_mmap.MMapControl(
                lmu_data.LMUConstants.LMU_SHARED_MEMORY_FILE,
                lmu_data.LMUObjectOut,
            )
            self._info.create(0)  # copy-access mode: avoids torn/partial reads
            self._ready = True
            return True
        except Exception as exc:
            print(f"[warn] could not attach to LMU shared memory yet: {exc}")
            self._ready = False
            return False

    def read_my_car(self):
        """
        Returns a dict with tyreTemps, tyreWear, and damage for the
        player's car, or None if shared memory isn't ready or LMU
        doesn't currently have a player vehicle (e.g. in a menu).
        """
        if not self._ready:
            return None

        try:
            self._info.update()
            telemetry = self._info.data.telemetry
            if not telemetry.playerHasVehicle:
                return None
            car = telemetry.telemInfo[telemetry.playerVehicleIdx]
        except Exception as exc:
            print(f"[warn] shared memory read failed, will retry: {exc}")
            self._ready = False
            return None

        tyre_temps = {}
        tyre_wear = {}
        detached_corners = []
        flat_corners = []

        for corner, wheel in zip(WHEEL_CORNERS, car.mWheels):
            # mTemperature holds 3 samples across the tread width, in
            # Kelvin. We average them into one Celsius reading per corner.
            samples_c = [sample - 273.15 for sample in wheel.mTemperature]
            tyre_temps[corner] = round(sum(samples_c) / len(samples_c), 1)
            tyre_wear[corner] = round(wheel.mWear * 100, 1)  # 0-1 fraction -> percent

            if wheel.mDetached:
                detached_corners.append(corner)
            if wheel.mFlat:
                flat_corners.append(corner)

        dent_severity = list(car.mDentSeverity)  # 8 body locations, 0=none
        body_damaged = bool(car.mDetached) or any(d > 0 for d in dent_severity)

        damage_notes = []
        if detached_corners:
            damage_notes.append(f"wheel detached: {', '.join(detached_corners)}")
        if flat_corners:
            damage_notes.append(f"flat tyre: {', '.join(flat_corners)}")
        if body_damaged:
            max_dent = max(dent_severity) if dent_severity else 0
            damage_notes.append(f"bodywork damage (severity {max_dent})")

        return {
            "tyreTemps": tyre_temps,
            "tyreWear": tyre_wear,
            "damage": damage_notes if damage_notes else None,
            "lastImpactMagnitude": round(car.mLastImpactMagnitude, 1),
            "setup": self._read_setup_fields(car),
        }

    def _read_setup_fields(self, car):
        """
        Driver-adjustable settings (TC, ABS, brake bias, etc). Field
        names confirmed against a real full-struct dump from LMU:
        mTC, mTCCut, mTCSlip, mABS, mMigration, mRearBrakeBias all
        exist and return real values. Front/rear brake duct blanking
        and rear wing setting were checked against the FULL field list
        (90 fields) and genuinely don't exist anywhere in LMU's
        telemetry struct - not a guessing-error, they're just not
        exposed via this data source for any car.
        """
        def safe_get(name, default=None):
            try:
                return getattr(car, name)
            except Exception:
                return default

        rear_brake_bias = safe_get("mRearBrakeBias")

        return {
            "tc": safe_get("mTC"),
            "tcMax": safe_get("mTCMax"),
            "tcCut": safe_get("mTCCut"),
            "tcCutMax": safe_get("mTCCutMax"),
            "tcSlip": safe_get("mTCSlip"),
            "tcSlipMax": safe_get("mTCSlipMax"),
            "brakeBias": round(rear_brake_bias * 100, 1) if rear_brake_bias is not None else None,
            "abs": safe_get("mABS"),
            "absMax": safe_get("mABSMax"),
            "brakeMigration": safe_get("mMigration"),
            "brakeMigrationMax": safe_get("mMigrationMax"),
            # Confirmed NOT present anywhere in LMU's telemetry struct -
            # not available via this data source, for any car/class.
            "frontBrakeDuctBlanking": None,
            "rearBrakeDuctBlanking": None,
            "rearWing": None,
        }

    def _dump_struct_fields(self, struct_obj, max_array_items=8):
        """
        Introspects a ctypes Structure and returns {field_name: value}
        for all of its fields, converting to JSON-safe types. Used to
        discover real field names (e.g. for TC/ABS/brake bias, penalty
        type) without guessing - the "Raw data" panel on the dashboard
        will show exactly what's actually available on the real struct.
        Nested structures/arrays are summarized rather than fully
        expanded, to keep the debug dump readable.
        """
        def json_safe(value):
            """Converts a raw field value into something json.dumps can handle."""
            if isinstance(value, bytes):
                return value.decode("utf-8", errors="replace").rstrip("\x00")
            if isinstance(value, (int, float, bool, str)):
                return value
            return str(value)

        result = {}
        try:
            fields = getattr(struct_obj, "_fields_", None)
            if not fields:
                return {"_error": "not a ctypes Structure or has no _fields_"}
            for name, _type in fields:
                try:
                    value = getattr(struct_obj, name)
                except Exception as exc:
                    result[name] = f"<error reading: {exc}>"
                    continue

                if isinstance(value, (int, float, bool, str, bytes)):
                    result[name] = json_safe(value)
                elif hasattr(value, "_fields_"):
                    result[name] = "<nested struct - see dedicated section if needed>"
                elif hasattr(value, "__len__"):
                    try:
                        items = list(value)[:max_array_items]
                        result[name] = [
                            json_safe(item) if isinstance(item, (int, float, bool, str, bytes))
                            else "<nested>"
                            for item in items
                        ]
                    except Exception:
                        result[name] = "<array - could not read>"
                else:
                    result[name] = str(value)
        except Exception as exc:
            result["_error"] = str(exc)
        return result

    def read_debug_info(self):
        """
        Returns a broader debug dump: every field on the player's car
        telemetry struct, plus the names of top-level sections available
        in the shared memory block (e.g. scoring/telemetry/rules/...).
        This is what lets us find real field names (penalty type, TC,
        ABS, etc.) from a single raw data share instead of guessing
        one field at a time.
        """
        if not self._ready:
            return None
        try:
            telemetry = self._info.data.telemetry
            if not telemetry.playerHasVehicle:
                return None
            car = telemetry.telemInfo[telemetry.playerVehicleIdx]

            top_level_sections = []
            data_fields = getattr(self._info.data, "_fields_", [])
            for name, _type in data_fields:
                top_level_sections.append(name)

            rules_dump = None
            if hasattr(self._info.data, "rules"):
                rules_dump = self._dump_struct_fields(self._info.data.rules)

            return {
                "availableTopLevelSections": top_level_sections,
                "allCarTelemetryFields": self._dump_struct_fields(car),
                "rulesSection": rules_dump,
            }
        except Exception as exc:
            return {"_error": str(exc)}

    def close(self):
        if self._info:
            try:
                self._info.close()
            except Exception:
                pass
        self._ready = False
