# Race Engineer - Setup

## First time on this PC

1. Extract this whole zip anywhere (Desktop, Downloads, doesn't matter).
2. Double-click **`install.bat`**.
3. It copies everything to `C:\PitlaneRaceEngineer` and adds a
   **"Race Engineer"** shortcut to your Desktop.
4. Once that's done, you can delete this extracted folder - everything
   it needs now lives in `C:\PitlaneRaceEngineer`.

## Every time you race

1. Make sure Le Mans Ultimate is running (Settings -> Gameplay ->
   Enable Plugins = ON).
2. Double-click the **"Race Engineer"** shortcut on your Desktop.
3. First time only: it'll ask for your team's room code. Don't have one
   yet? One person on the team should create it first at:
   https://raceapp.pitlane.gr/create
   then share that code with everyone else.
4. It opens your team's shared dashboard automatically in your browser -
   the same page everyone else on the team is watching, whether they're
   driving or just spectating.

Keep the console window open while you race - closing it disconnects
you from the room. Everyone else keeps watching whatever was last sent
before you closed it, until you (or another driver) reconnects.
