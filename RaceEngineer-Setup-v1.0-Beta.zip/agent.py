"""
RE (Race Engineer) Agent
-------------------------
Polls Le Mans Ultimate's local REST API (http://localhost:6397) and
tracks ONE car - your team's - sending a focused set of race engineer
data to your team's shared room: gap ahead/behind, current lap,
fuel/energy, pit stops, tyres changed, damage, and tyre temps.

Run this on the PC that is actually running Le Mans Ultimate.
Requirements:
    - LMU running, with Settings -> Gameplay -> Enable Plugins turned ON
    - Python 3.9+
    - pip install -r requirements.txt

First run: you'll be asked for your team's room code (create one at
https://raceapp.pitlane.gr/create if you don't have one yet). After
that, this just starts and opens your team's shared dashboard link
automatically - same page for the driver and everyone watching.

Usage:
    python agent.py
"""

import asyncio
import json
import time
import webbrowser
from dataclasses import dataclass, field

import aiohttp

from lmu_shared_memory import SharedMemoryReader

LMU_BASE_URL = "http://localhost:6397"
STANDINGS_ENDPOINT = f"{LMU_BASE_URL}/rest/watch/standings"
SESSION_ENDPOINT = f"{LMU_BASE_URL}/rest/watch/sessionInfo"

POLL_INTERVAL_SECONDS = 1.0


# Your team's relay - fixed, since this never varies per driver/run.
DEFAULT_RELAY_URL = "https://raceapp.pitlane.gr"


def ask_room_code() -> str:
    """
    Asks for the team's room code every time the agent starts - not
    saved anywhere, since a shared PC might join different rooms for
    different events/races.
    """
    print("=" * 50)
    print(" RE (Race Engineer)")
    print("=" * 50)
    print("Don't have a room code yet? Create one first at:")
    print(f"  {DEFAULT_RELAY_URL}/create\n")

    while True:
        entered = input("Team room code: ").strip()
        if not entered:
            print("A room code is needed to see or share live data - please enter one.")
        elif " " in entered or len(entered) > 30:
            print("That doesn't look like a room code (room codes are short, no spaces) -")
            print("double check what you're pasting and try again.")
        else:
            return entered


# Car number stays on auto-detect (reliable once you're in a real
# session) and the relay is fixed to your team's own hosting - neither
# varies per run, so there's nothing to ask or save for those.
config = {"MY_CAR_NUMBER": "", "RELAY_URL": DEFAULT_RELAY_URL, "ROOM_CODE": ""}


@dataclass
class AgentState:
    last_payload: dict = field(default_factory=dict)
    last_pit_count: int = 0
    last_tyre_change_count: int = 0
    shared_memory: SharedMemoryReader = field(default_factory=SharedMemoryReader)
    shared_memory_connected: bool = False
    relay_connected: bool = False


state = AgentState()


async def fetch_json(session: aiohttp.ClientSession, url: str):
    try:
        async with session.get(url, timeout=aiohttp.ClientTimeout(total=2)) as resp:
            if resp.status == 200:
                return await resp.json(content_type=None)
    except Exception as exc:
        print(f"[warn] could not fetch {url}: {exc}")
    return None


def extract_cars(standings) -> list:
    if isinstance(standings, dict):
        return standings.get("cars") or standings.get("vehicles") or standings.get("results") or []
    if isinstance(standings, list):
        return standings
    return []


def find_my_car(cars: list):
    """
    Finds the team's car via auto-detect. Priority order matters here:

    1. The "player" flag - this marks which car your team actually
       OWNS/entered, and stays fixed all race regardless of who's
       driving or watching.
    2. "hasFocus"/"focus" as a last-resort fallback ONLY if no car has
       "player" set at all. These flags track the CAMERA view, not car
       ownership - they change every time someone spectates or cycles
       through other cars, so they must never take priority over
       "player", or the dashboard could start tracking a rival car
       whenever someone free-cams around the field.
    """
    for car in cars:
        if car.get("player"):
            return car

    for car in cars:
        if car.get("hasFocus") or car.get("focus"):
            return car
    return None


def build_payload(standings, session_info, telemetry_data) -> dict:
    cars = extract_cars(standings)

    # Sort by position so we can find the car directly ahead/behind.
    def pos_key(c):
        p = c.get("position") or c.get("place")
        try:
            return int(p)
        except (TypeError, ValueError):
            return 9999

    sorted_cars = sorted(cars, key=pos_key)

    my_car = find_my_car(sorted_cars)

    if my_car is None:
        if not cars:
            error_message = (
                "Waiting for an active race session — your car can only be "
                "detected once you're actually in a session with cars on "
                "track (not just sitting in a menu or garage screen)."
            )
        else:
            error_message = (
                "Could not find your car among the cars currently in session. "
                "Auto-detect looks for your team's car via LMU's own ownership "
                "flag - if this persists, check the raw standings data below "
                "to see what's actually available."
            )

        return {
            "type": "update",
            "timestamp": time.time(),
            "session": session_info or {},
            "myCar": None,
            "carAhead": None,
            "carBehind": None,
            "error": error_message,
            "rawStandings": cars,
        }

    my_id = my_car.get("id") or my_car.get("carNumber") or my_car.get("number")
    my_index = sorted_cars.index(my_car)
    car_ahead = sorted_cars[my_index - 1] if my_index > 0 else None
    car_behind = sorted_cars[my_index + 1] if my_index < len(sorted_cars) - 1 else None

    # Pit stop tracking (increment detection). Confirmed field: "pitstops".
    pit_count = my_car.get("pitstops", 0)
    if pit_count and pit_count > state.last_pit_count:
        pass  # a pit stop just completed; could trigger an alert/sound here later
    state.last_pit_count = pit_count

    # LMU's standings payload doesn't include a tyre-change counter directly -
    # only a pit stop count. If a dedicated field shows up in the telemetry
    # endpoint we'll pick it up here; otherwise this mirrors pit count as a
    # reasonable placeholder until we confirm the real field.
    tyre_change_count = (
        my_car.get("numTireChanges")
        or my_car.get("tyreChanges")
        or my_car.get("tireChangeCount")
    )
    if tyre_change_count is None:
        tyre_change_count = pit_count
    state.last_tyre_change_count = tyre_change_count

    my_telemetry = telemetry_data or {}

    def pct(fraction):
        """Converts a 0-1 fraction (fuelFraction, veFraction) to a rounded percentage."""
        if fraction is None:
            return None
        try:
            return round(float(fraction) * 100, 1)
        except (TypeError, ValueError):
            return None

    def gap_str(car):
        """
        LMU's confirmed field for 'gap to the car directly ahead' is
        timeBehindNext. Falls back to older guesses in case a build
        changes this.
        """
        if not car:
            return None
        value = car.get("timeBehindNext")
        if value is None:
            value = car.get("gap") or car.get("interval") or car.get("timeBehind")
        return value

    damage_notes = my_telemetry.get("damage")  # list of strings, or None if no damage
    penalty_count = my_car.get("penalties", 0)
    # Confirmed via full shared-memory field dump: penalty TYPE (SG/DT/time)
    # isn't exposed anywhere - not in REST, not in the telemetry struct's ~90
    # fields, and there's no separate "Rules" data section either. These
    # fallback field names are kept in case a future LMU build adds it, but
    # currently this will always be None - that's a confirmed data
    # limitation, not a bug to keep chasing.
    penalty_type = (
        my_car.get("penaltyType")
        or my_car.get("currentPenalty")
        or my_car.get("servingPenalty")
    )

    def find_time_remaining(session):
        """
        Confirmed from real session data: LMU's sessionInfo REST payload
        already provides "timeRemainingInGamePhase" - the correct,
        game-calculated time left in the current race phase (accounts
        for formation lap / green flag delay, not just a raw countdown
        from total session length). We fall back to computing it
        manually from endEventTime - currentEventTime if that field
        isn't present for some reason.
        """
        if not session:
            return None
        if "timeRemainingInGamePhase" in session:
            return session["timeRemainingInGamePhase"]
        if "endEventTime" in session and "currentEventTime" in session:
            return session["endEventTime"] - session["currentEventTime"]
        return None

    setup = my_telemetry.get("setup") or {}

    return {
        "type": "update",
        "timestamp": time.time(),
        "session": session_info or {},
        "timeRemaining": find_time_remaining(session_info),
        "sectorFlags": (session_info or {}).get("sectorFlag"),
        "yellowFlagState": (session_info or {}).get("yellowFlagState"),
        "myCar": {
            "carNumber": my_car.get("carNumber"),
            "team": my_car.get("fullTeamName") or my_car.get("teamName"),
            "driver": my_car.get("driverName"),
            "carClass": my_car.get("carClass"),
            "position": my_car.get("position"),
            "lap": my_car.get("lapsCompleted"),
            "lastLapTime": my_car.get("lastLapTime"),
            "bestLapTime": my_car.get("bestLapTime"),
            "fuel": pct(my_car.get("fuelFraction")),
            "energy": pct(my_car.get("veFraction")),
            "pitCount": pit_count,
            "tyreChangeCount": tyre_change_count,
            "inPit": bool(my_car.get("pitting")),
            "pitState": my_car.get("pitState"),
            "penaltyCount": penalty_count,
            "penaltyType": penalty_type,
            "finishStatus": my_car.get("finishStatus"),
            "flag": my_car.get("flag"),
            "damage": damage_notes,
            "damageAvailable": state.shared_memory_connected,
            "tyreTemps": my_telemetry.get("tyreTemps"),
            "tyreWear": my_telemetry.get("tyreWear"),
            "setup": setup,
        },
        "carAhead": {
            "driver": car_ahead.get("driverName") if car_ahead else None,
            "carNumber": car_ahead.get("carNumber") if car_ahead else None,
            "gap": gap_str(my_car),  # my_car's own timeBehindNext = interval to the car ahead
        } if car_ahead else None,
        "carBehind": {
            "driver": car_behind.get("driverName") if car_behind else None,
            "carNumber": car_behind.get("carNumber") if car_behind else None,
            "gap": gap_str(car_behind),  # car_behind's own timeBehindNext = interval to my_car
        } if car_behind else None,
        "raw": {
            "myCar": my_car,
            "myTelemetry": my_telemetry,
            "sharedMemoryDebug": my_telemetry.get("_debug"),
        },
    }


async def poll_loop():
    async with aiohttp.ClientSession() as http:
        while True:
            try:
                if not state.shared_memory_connected:
                    state.shared_memory_connected = state.shared_memory.connect()

                telemetry_data = None
                if state.shared_memory_connected:
                    telemetry_data = state.shared_memory.read_my_car()
                    if telemetry_data is None:
                        # Either LMU has no player vehicle right now (menu/replay),
                        # or the read failed and reader flagged itself for reconnect.
                        state.shared_memory_connected = state.shared_memory._ready
                    else:
                        telemetry_data["_debug"] = state.shared_memory.read_debug_info()

                standings, session_info = await asyncio.gather(
                    fetch_json(http, STANDINGS_ENDPOINT),
                    fetch_json(http, SESSION_ENDPOINT),
                )
                payload = build_payload(standings, session_info, telemetry_data)
                state.last_payload = payload
            except Exception as exc:
                # Absolute last-resort safety net: log and keep the loop alive
                # rather than letting any unexpected error take the agent down.
                print(f"[warn] poll loop iteration failed, continuing: {exc}")

            await asyncio.sleep(POLL_INTERVAL_SECONDS)


async def relay_push_loop():
    """
    POSTs the latest payload to the relay server every poll interval via
    plain HTTP, so the driver and every teammate watching all see the
    same shared room. Uses ordinary HTTP requests (not WebSockets) so it
    works on any standard web hosting, including shared/Plesk hosting.
    """
    relay_url = (config.get("RELAY_URL") or DEFAULT_RELAY_URL).strip()
    room_code = (config.get("ROOM_CODE") or "").strip()

    if not room_code:
        print("[warn] No room code - nothing will be shared anywhere.")
        return

    publish_url = f"{relay_url.rstrip('/')}/api/publish?room={room_code}"
    print(f"[info] Remote viewing enabled - publishing to relay room '{room_code}'")

    async with aiohttp.ClientSession() as session:
        last_sent_timestamp = None
        while True:
            payload = state.last_payload
            if payload and payload.get("timestamp") != last_sent_timestamp:
                try:
                    body = json.dumps(payload, default=str)
                    async with session.post(
                        publish_url,
                        data=body,
                        headers={"Content-Type": "application/json"},
                        timeout=aiohttp.ClientTimeout(total=3),
                    ) as resp:
                        if resp.status == 200:
                            state.relay_connected = True
                            last_sent_timestamp = payload.get("timestamp")
                        else:
                            state.relay_connected = False
                            print(f"[warn] relay rejected update: HTTP {resp.status}")
                except Exception as exc:
                    state.relay_connected = False
                    print(f"[warn] could not reach relay, will retry: {exc}")
            await asyncio.sleep(1.0)


async def main():
    room_code = ask_room_code()
    config["ROOM_CODE"] = room_code
    relay_url = DEFAULT_RELAY_URL

    print("\nRE (Race Engineer) Agent")
    print(f"Tracking car number: {config.get('MY_CAR_NUMBER') or '(auto-detect)'}")
    print(f"Polling {LMU_BASE_URL} every {POLL_INTERVAL_SECONDS}s")

    from lmu_shared_memory import SHARED_MEMORY_AVAILABLE
    if SHARED_MEMORY_AVAILABLE:
        print("Shared memory library found - will attempt to read tyre temps/damage.")
    else:
        print("[warn] pyLMUSharedMemory not found next to agent.py - tyre temps and "
              "damage will be unavailable. Run start_dashboard.bat/setup.ps1 again "
              "to fetch it, or see README.md.")

    room_link = f"{relay_url.rstrip('/')}/?room={room_code}"
    print(f"Opening your team's room: {room_link}")
    webbrowser.open(room_link)

    await asyncio.gather(poll_loop(), relay_push_loop())


if __name__ == "__main__":
    asyncio.run(main())
