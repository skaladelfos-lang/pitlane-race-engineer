@echo off
cd /d "%~dp0"
title Installing Race Engineer

echo ==========================================
echo  Installing Race Engineer
echo ==========================================
echo.

set "INSTALL_DIR=C:\PitlaneRaceEngineer"

echo Copying files to %INSTALL_DIR% ...
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"

copy /Y "agent.py" "%INSTALL_DIR%\agent.py" >nul
copy /Y "lmu_shared_memory.py" "%INSTALL_DIR%\lmu_shared_memory.py" >nul
copy /Y "requirements.txt" "%INSTALL_DIR%\requirements.txt" >nul
copy /Y "run_race_engineer.bat" "%INSTALL_DIR%\run_race_engineer.bat" >nul
copy /Y "RaceEngineer.ico" "%INSTALL_DIR%\RaceEngineer.ico" >nul

if exist "pyLMUSharedMemory" (
    xcopy /Y /E /I "pyLMUSharedMemory" "%INSTALL_DIR%\pyLMUSharedMemory\" >nul
)

echo Files copied.
echo.

echo Creating Desktop shortcut...
set "SHORTCUT_PS=%TEMP%\create_shortcut.ps1"
(
echo $WshShell = New-Object -ComObject WScript.Shell
echo $Shortcut = $WshShell.CreateShortcut^("$env:USERPROFILE\Desktop\Race Engineer.lnk"^)
echo $Shortcut.TargetPath = "%INSTALL_DIR%\run_race_engineer.bat"
echo $Shortcut.WorkingDirectory = "%INSTALL_DIR%"
echo $Shortcut.IconLocation = "%INSTALL_DIR%\RaceEngineer.ico"
echo $Shortcut.Description = "PITLANE.GR Race Engineer"
echo $Shortcut.Save^(^)
) > "%SHORTCUT_PS%"

powershell -NoProfile -ExecutionPolicy Bypass -File "%SHORTCUT_PS%"
del "%SHORTCUT_PS%" >nul 2>nul

echo.
echo ==========================================
echo  Done!
echo ==========================================
echo.
echo Installed to: %INSTALL_DIR%
echo A "Race Engineer" shortcut has been added to your Desktop.
echo.
echo You can delete this downloaded/unzipped folder now if you like -
echo everything needed lives in %INSTALL_DIR% from here on.
echo.
echo Double-click the Desktop shortcut to start racing.
echo.
pause
