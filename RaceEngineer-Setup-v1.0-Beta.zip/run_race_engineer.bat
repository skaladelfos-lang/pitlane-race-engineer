@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"
title Race Engineer

where python >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Python was not found on this PC.
    echo Please install Python 3.9+ from https://www.python.org/downloads/
    echo IMPORTANT: during install, tick "Add Python to PATH".
    echo Then run this shortcut again.
    pause
    exit /b 1
)

python --version 2>&1 | findstr /C:"was not found" >nul
if %errorlevel% equ 0 (
    echo [ERROR] Windows is redirecting "python" to the Microsoft Store instead
    echo of running a real Python install. This is a common Windows quirk, not
    echo a real missing-Python problem. To fix it:
    echo.
    echo   1. Open: Settings -^> Apps -^> Advanced app settings -^> App execution aliases
    echo   2. Turn OFF the "App Installer" entries for python.exe and python3.exe
    echo   3. If you haven't already, install Python from https://www.python.org/downloads/
    echo      and tick "Add Python to PATH" during install.
    echo   4. Run this shortcut again.
    echo.
    pause
    exit /b 1
)

if not exist ".setup_done" (
    echo Installing required packages - this only happens once...
    python -m pip install -r requirements.txt

    if !errorlevel! neq 0 (
        echo [ERROR] Failed to install dependencies. Check your internet connection.
        pause
        exit /b 1
    )

    if not exist "pyLMUSharedMemory\lmu_mmap.py" (
        echo Fetching pyLMUSharedMemory ^(tyre temps + damage library^)...
        powershell -NoProfile -Command "try { Invoke-WebRequest -Uri 'https://github.com/TinyPedal/pyLMUSharedMemory/archive/refs/heads/master.zip' -OutFile 'pyLMUSharedMemory.zip' -UseBasicParsing; Expand-Archive -Path 'pyLMUSharedMemory.zip' -DestinationPath 'pyLMUSharedMemory_extract' -Force; $inner = Get-ChildItem 'pyLMUSharedMemory_extract' -Directory | Select-Object -First 1; Move-Item $inner.FullName 'pyLMUSharedMemory'; Remove-Item 'pyLMUSharedMemory.zip' -Force; Remove-Item 'pyLMUSharedMemory_extract' -Recurse -Force; Write-Host 'pyLMUSharedMemory installed.' } catch { Write-Host 'Could not auto-download pyLMUSharedMemory - tyre temps/damage will be unavailable.' }"
    )

    echo done > ".setup_done"
    echo.
)

echo Make sure Le Mans Ultimate is running with:
echo   Settings -^> Gameplay -^> Enable Plugins = ON
echo.
echo (Keep this window open while you race - closing it disconnects you)
echo.

python agent.py

pause
